# PayPal Add-on

**Download link:**

https://codecanyon.net/item/super-forms-paypal-addon/21048964


**Documentation:**

http://f4d.nl/super-forms-documentation/paypal-add-on/readme.html