# Form redirect

When you wish to redirect a user to a custom thank you page, or maybe to a other page you can enable the **Form redirect option** option.

This option can redirect a user to a **Custom URL** or a **Existing Page**.

You can enable this option under `Form Settings > Form Settings` via **Form redirect option**.
