# Javascript Hooks

// @since 1.0.0
before_validating_form_hook
after_validating_form_hook
after_initializing_forms_hook
after_dropdown_change_hook
after_field_change_blur_hook
after_radio_change_hook
after_checkbox_change_hook

// @since 1.2.8
after_email_send_hook

// @since 1.3.0
after_responsive_form_hook
after_form_data_collected_hook
after_duplicate_column_fields_hook

// @since 1.9.0
before_submit_button_click_hook
after_preview_loaded_hook

// @since 2.0.0
after_form_cleared_hook

// @since 2.1.0
before_scrolling_to_error_hook
before_scrolling_to_message_hook

// @since 2.4.0
after_duplicating_column_hook

// @since 3.2.0
super_common_i18n_filter
super_elements_i18n_filter